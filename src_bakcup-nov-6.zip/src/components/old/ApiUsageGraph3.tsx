import React, { useRef, useEffect } from 'react';
import Chart from 'chart.js/auto';

interface UsageEntry {
  date: string;        // Date and time in ISO format
  query_count: number; // Query count for that hour
}

interface UsageChartProps {
  usages: UsageEntry[]; // Array of usage entries
  // hour_limit: number; 
}

const UsageChart: React.FC<UsageChartProps> = ({ usages }) => {
  const chartRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstance = useRef<Chart | null>(null);
  const timestamps = usages.map(entry => new Date(entry.date).getTime());
  const minDate = new Date(Math.min(...timestamps));
  const maxDate = new Date(Math.max(...timestamps));

  useEffect(() => {
    if (chartRef.current) {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      // Process the usages array to get the labels (dates) and data (query counts)
      const labels = usages.map(entry => {
        const date = new Date(entry.date);
        return `${date.toLocaleDateString()} ${date.getHours()}:00`;
      });
      const chartData = usages.map(entry => entry.query_count);

      // Calculate date range using timestamps
      const timestamps = usages.map(entry => new Date(entry.date).getTime());
      const minDate = new Date(Math.min(...timestamps));
      const ctx = chartRef.current?.getContext('2d');

      const gradient = ctx?.createLinearGradient(0, 0, 0, 800);
      if (gradient) {
        gradient.addColorStop(0, 'rgba(247,147,27,0.5)');
        gradient.addColorStop(1, 'rgba(247,147,27,0)');
      }

      const chartConfig = {
        labels: labels,
        datasets: [
          {
            label: `Hourly Usage`,
            fill: true,
            data: chartData,
            backgroundColor: gradient, // Use the gradient here
            borderColor: '#F7931B',
            tension: 0.1,
            pointBackgroundColor: '#F7931B',
          }
        ]
      };

      chartInstance.current = new Chart(chartRef.current, {
        type: 'line',
        data: chartConfig,
        options: {
          scales: {
              x: {
                  type: 'time',
                  time: {
                      unit: 'hour',
                      displayFormats: {
                          hour: 'MMM D, hA'
                      }
                  },
                  ticks: {
                      maxRotation: 45, // Angle in degrees
                      minRotation: 45, // Ensure that the rotation doesn't change on resize
                      autoSkip: true,
                      maxTicksLimit: 20 // Adjust based on your preference
                  }
              }
          }
      }
      });      
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy(); // Cleanup function
      }
    };
  }, [usages]);

  return <canvas className="usage" ref={chartRef}></canvas>;
};

export default UsageChart;