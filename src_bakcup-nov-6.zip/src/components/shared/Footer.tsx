import React from 'react';

function Footer() {
  return (
    <footer>
      <div className='footer'>
      <center>
      <p>&copy; {new Date().getFullYear()} Best In Slot</p>
      </center>
      </div>
    </footer>
  );
}

export default Footer;